﻿//using System.Collections.ObjectModel;
//using GalaSoft.MvvmLight;
//using TaskTester.DesktopTester.Model;
//using System.Windows.Input;
//using GalaSoft.MvvmLight.Command;
//using Microsoft.Win32;

//namespace TaskTester.DesktopTester.ViewModel
//{
//    class CheckerViewModel : ViewModelBase
//    {
//        public Checker Model { get; private set; }

//        public string ExecutablePath
//        {
//            get { return Model.ExecutablePath; }
//            set
//            {
//                Model.ExecutablePath = value;
//                RaisePropertyChanged(nameof(ExecutablePath));
//            }
//        }

//        public ObservableCollection<CheckerBindingViewModel> Bindings { get; private set; } =
//            new ObservableCollection<CheckerBindingViewModel>();
//        public ObservableCollection<ArgumentViewModel> Arguments { get; private set; } =
//            new ObservableCollection<ArgumentViewModel>();

//        public ICommand BrowseExecutable { get; private set; }

//        public CheckerViewModel() : this(null) { }

//        public CheckerViewModel(Checker model = null)
//        {
//            this.Model = model;

//            BrowseExecutable = new RelayCommand(BrowseExecutableExecute);

//            if (model == null) { return; }

//            foreach (CheckerBinding binding in model.Bindings)
//            {
//                Bindings.Add(new CheckerBindingViewModel(binding));
//            }

//            foreach (Argument argument in model.Arguments)
//            {
//                Arguments.Add(new ArgumentViewModel(argument));
//            }
//        }

//        private void BrowseExecutableExecute()
//        {
//            OpenFileDialog dialog = new OpenFileDialog {
//                AddExtension = false,
//                Multiselect = false,
//                Filter = "Console Application |*.exe"
//            };

//            dialog.ShowDialog();

//            if (string.IsNullOrEmpty(dialog.FileName) || dialog.CheckFileExists)
//            {
//                ExecutablePath = dialog.FileName;
//                RaisePropertyChanged("ExecutablePath");
//                RaisePropertyChanged("RunTests");
//            }
//        }
//    }
//}
