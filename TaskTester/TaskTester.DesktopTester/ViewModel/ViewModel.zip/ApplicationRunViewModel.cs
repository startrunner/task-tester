﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Windows.Input;
//using GalaSoft.MvvmLight;
//using GalaSoft.MvvmLight.CommandWpf;
//using Microsoft.Win32;
//using TaskTester.DesktopTester.Model;
//using System.IO;
//using System.Collections.ObjectModel;

//namespace TaskTester.DesktopTester.ViewModel
//{
//    class ApplicationRunViewModel : ViewModelBase
//    {
//        public ApplicationRun Model { get; private set; }
//        public int CompletedTestsCount => Feedback?.Count ?? 3;
//        public int AllTestsCount => Model?.InputFiles?.Count ?? 10;

//        public string ExecutablePath { get; private set; }
//        public string InputPaths { get; private set; }
//        public CheckerViewModel Checker { get; set; } = new CheckerViewModel();
//        public string SolutionPaths { get; private set; }

//        private string _timeLimit;
//        public string TimeLimit
//        {
//            get { return _timeLimit; }
//            set
//            {
//                _timeLimit = value;

//                if (double.TryParse(value, out double timeLimit))
//                {
//                    Model.TimeLimit = TimeSpan.FromSeconds(timeLimit);
//                }
//                else
//                {
//                    Model.TimeLimit = null;
//                }

//                RaisePropertyChanged("RunTests");
//            }
//        }

//        public ICommand BrowseExecutable { get; private set; }
//        public ICommand BrowseInputs { get; private set; }
//        public ICommand BrowseSolutions { get; private set; }
//        public ICommand RunTests { get; private set; }
//        public ICommand EditChecker { get; private set; }

//        public ApplicationRunViewModel()
//        {
//            BrowseExecutable = new RelayCommand(BrowseExecutableExecute);
//            BrowseInputs = new RelayCommand(BrowseInputsExecute);
//            BrowseSolutions = new RelayCommand(BrowseSolutionsExecute);
//            RunTests = new RelayCommand(RunTestsExecute, RunTestsCanExecute);
//        }

//        private bool RunTestsCanExecute()
//        {
//            if (IsInDesignMode) return true;
//            return Model.IsValidForExecution;
//        }

//        private void RunTestsExecute()
//        {
//            ;
//            Feedback.Clear();
//            RaisePropertyChanged("CompletedTestsCount");
//            RaisePropertyChanged("AllTestsCount");

//            RaisePropertyChanged("Feedback");

//            Model.RunTestsAsync().GetAwaiter();
//        }

//        private void BrowseSolutionsExecute()
//        {
//            OpenFileDialog dialog = new OpenFileDialog {
//                AddExtension = false,
//                Multiselect = true,
//                Filter = "Test Solution File |*.sol; *.out |Any File|*.*"
//            };

//            dialog.ShowDialog();

//            if (dialog.FileNames.Length != 0 && dialog.CheckFileExists)
//            {
//                List<FileInfo> files = dialog.FileNames.Select(x => new FileInfo(x)).ToList();
//                Model.SolutionFiles = files;

//                SolutionPaths = string.Join(";", dialog.FileNames);
//                RaisePropertyChanged("SolutionPaths");
//                RaisePropertyChanged("RunTests");
//            }
//        }

//        private void BrowseInputsExecute()
//        {
//            OpenFileDialog ofd = new OpenFileDialog {
//                AddExtension = false,
//                Multiselect = true,
//                Filter = "Test Input File |*.in; *.inp |Any File|*.*"
//            };

//            ofd.ShowDialog();

//            if (ofd.FileNames.Length != 0 && ofd.CheckFileExists)
//            {
//                List<FileInfo> files = ofd.FileNames.Select(x => new FileInfo(x)).ToList();
//                Model.InputFiles = files;

//                InputPaths = string.Join(";", ofd.FileNames);
//                RaisePropertyChanged("InputPaths");
//                RaisePropertyChanged("RunTests");
//            }
//        }

//        private void BrowseExecutableExecute()
//        {
//            OpenFileDialog ofd = new OpenFileDialog {
//                AddExtension = false,
//                Multiselect = false,
//                Filter = "Console Application |*.exe"
//            };

//            ofd.ShowDialog();

//            if (ofd.FileName != "" && ofd.CheckFileExists)
//            {
//                Model.ExecutableFile = new FileInfo(ofd.FileName);
//                ExecutablePath = ofd.FileName;
//                RaisePropertyChanged("ExecutablePath");
//                RaisePropertyChanged("RunTests");
//            }

//        }



//        public ApplicationRunViewModel(ApplicationRun problem) : this()
//        {
//            this.Model = problem;
//            this.Checker = new CheckerViewModel(Model.Checker);
//            this._timeLimit = Model.TimeLimit.GetValueOrDefault().TotalSeconds.ToString();
//            problem.OneTestCompleted += OnOneTestCompleted;
//            problem.AllTestsCompleted += OnAllTestsCompleted;
//        }

//        private void OnAllTestsCompleted(ApplicationRun sender, List<TestResult> results)
//        {
//            RaisePropertyChanged("RunTests");
//        }

//        public ObservableCollection<TestResultViewModel> Feedback { get; set; } = new ObservableCollection<TestResultViewModel>();

//        private void OnOneTestCompleted(ApplicationRun sender, TestResult result)
//        {
//            Feedback.Add(new TestResultViewModel(result));
//            //RaisePropertyChanged("Feedback");
//            RaisePropertyChanged("CompletedTestsCount");
//        }
//    }
//}
