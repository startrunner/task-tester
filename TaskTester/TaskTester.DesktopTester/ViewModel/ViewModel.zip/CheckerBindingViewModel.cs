﻿//using GalaSoft.MvvmLight;
//using TaskTester.CheckerCore.OutputVerification;
//using TaskTester.DesktopTester.Model;

//namespace TaskTester.DesktopTester.ViewModel
//{
//    class CheckerBindingViewModel : ViewModelBase
//    {
//        public CheckerBinding Model { get; set; }

//        public OutputVerificationResultType Type
//        {
//            get => Model.ResultType;
//            set => Model.ResultType = value;
//        }

//        public string SearchString
//        {
//            get => Model?.SearchString ?? "@@@@";
//            set => Model.SearchString = value;
//        }

//        public string Score
//        {
//            get => Model.ScoreMultiplier.ToString();
//            set => 
//                Model.Score =
//                double.TryParse(value, out double parsedValue)?
//                parsedValue :
//                Model.ScoreMultiplier;
//        }

//        public CheckerBindingViewModel(CheckerBinding model) => Model = model;
//    }
//}
